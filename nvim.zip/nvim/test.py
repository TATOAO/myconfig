import pandas as pd
import sys 

print(sys.path)

pd.read_csv()

class j():
    def this_is_my_function(alan="name"):
        """
        this is a definition


        """
        return "ssss"


    def fjwiefj(jwefjoiwej):
        for i in range(10):
            for j in range(k):
                print("shit")


print('xxxxx')
print(('hi'
       'sjdfljweiljfilwef'
       'wefwefjwelifjiwefj'
       ))

o = 'sssss'


k = 1


j = j
jjsfefsefnn

k += 1


this_is_my_function()




print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('sssss')
print('a')





















