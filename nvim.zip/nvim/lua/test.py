
import yaml

f = open("test.yaml", 'r')
data = yaml.safe_load(f)
f.close()

## ojwef ojweofj
print(data)

