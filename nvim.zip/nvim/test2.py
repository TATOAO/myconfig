from test import this_is_my_function

import pandas as pd

this_is_my_function(alan = 'xxxx')

df = pd.read_csv("dss.csv")

from mymodule import *

