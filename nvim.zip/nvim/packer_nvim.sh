desitination_folder='~/Downloads/neovim_packed'
# zip config 
zip -r "$desitination_folder/nvim_config.zip"  ~/.config/nvim/ 
