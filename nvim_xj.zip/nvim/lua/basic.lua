vim.g.encoding = "UTF-8"


-- set up nvimTree
vim.g.loaded = 1
vim.g.loaded_netrwPlugin = 1

local status, nvim_tree = pcall(require, "nvim-tree")
if not status then
    vim.notify("没有找到 nvim-tree")
  return
end


nvim_tree.setup()


-- set up catppuccin
vim.g.catppuccin_flavour = "macchiato" -- latte, frappe, macchiato, mocha


-- set up bufferline
-- vim.opt.termguicolors = true
require("bufferline").setup{}

