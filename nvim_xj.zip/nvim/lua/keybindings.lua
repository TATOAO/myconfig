
local map = vim.api.nvim_set_keymap
-- 复用 opt 参数
local opt = {noremap = true, silent = true }

map("v", "J", ":move '>+1<CR>gv-gv", opt)
map("v", "K", ":move '<-2<CR>gv-gv", opt)




-- Nevigation pane resize
-- Alt/Opt + h
map("n", "˙", ":vertical resize -1 <CR>", opt)
-- Alt/Opt + l
map("n", "¬", ":vertical resize +1 <CR>", opt)
-- Alt/Opt + j
map("n", "∆", ":resize +1<CR>", opt)
-- Alt/Opt + k
map("n", "˚", ":resize -1<CR>", opt)



-- nvimTree
-- Alt/Opt + m
map("n", "µ", ":NvimTreeToggle<CR>", opt)
