local packer = require("packer")
packer.startup(
  function(use)
   -- Packer 可以管理自己本身
   use 'wbthomason/packer.nvim'
   -- 你的插件列表...
   --
   -- colorscheme lush
   use "rktjmp/lush.nvim"

   -- tokyonight
   use("folke/tokyonight.nvim")

   -- oceanic next
   use('mhartington/oceanic-next')

   -- catppuccin
   use { "catppuccin/nvim", as = "catppuccin" }

   -- bufferline 
   use {'akinsho/bufferline.nvim', tag = "v2.*", requires = 'kyazdani42/nvim-web-devicons'}

   -- nvim-tree
   use {
	  'kyazdani42/nvim-tree.lua',
	  requires = {
	    'kyazdani42/nvim-web-devicons', -- optional, for file icons
	  },
	  tag = 'nightly' -- optional, updated every week. (see issue #1193)
       }

end)
