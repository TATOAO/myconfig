require('basic')

require("keybindings")

require("plugins")

require("colorscheme")
